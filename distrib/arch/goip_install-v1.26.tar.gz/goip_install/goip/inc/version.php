<?php
$version="V1.26";
$bdate="Build 201904";
?>
